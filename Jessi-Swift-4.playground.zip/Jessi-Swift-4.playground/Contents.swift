import UIKit

// Define the base protocol- Monster
protocol Monster {
    var name: String { get }
    func roar() -> String
    }
 
// Define Child Protocols- Flying Monster, Water Monster
protocol FlyingMonster: Monster {
    var wingSpan: Double { get }
    func fly() -> String
}
protocol WaterMonster: Monster {
    var swimSpeed: Int { get }
    func swim() -> String
}

// Create the Sub-Classes of Monsters. - Dragon, Gryphon, Kraken, Merfolk
class Dragon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    }
    func roar() -> String {
        return "\(name) the dragon roars valiently!"
    }
    func fly() -> String {
        return "\(name) dominates the sky with a wingspan of \(wingSpan) meters."
    }
}
class Gryphon: FlyingMonster {
    var name: String
    var wingSpan: Double

    init(name: String, wingSpan: Double) {
        self.name = name
        self.wingSpan = wingSpan
    }
    func roar() -> String {
        return "\(name) the gryphon screeches with such ferocity!"
    }
    func fly() -> String {
        return "\(name) soars with such grace due to it's wingspan of \(wingSpan) meters."
    }
}
class Kraken: WaterMonster {
    var name: String
    var swimSpeed: Int

    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    }
    func roar() -> String {
        return "\(name) the kraken lets out a thunderous screech from Davy Jone's Locker!"
    }
    func swim() -> String {
        return "\(name) catapults through the sea at an uncatchable speed of \(swimSpeed) knots."
    }
}

class Merfolk: WaterMonster {
    var name: String
    var swimSpeed: Int

    init(name: String, swimSpeed: Int) {
        self.name = name
        self.swimSpeed = swimSpeed
    }

    func roar() -> String {
        return "\(name) the merfolk belts out a soothing melody!"
    }

    func swim() -> String {
        return "\(name) glides through the water at a leisurely \(swimSpeed) knots."
    }
}
// Create the function to handle the different monsters.
func printMonsterDetails(monsters: [Monster]) {
    for monster in monsters {
        print(monster.roar())

        if let flyingMonster = monster as? FlyingMonster {
            print(flyingMonster.fly())
        } else if let waterMonster = monster as? WaterMonster {
            print(waterMonster.swim())
        }
        print("~~~~~~~")
         }
     }
let dragon = Dragon(name: "Kilgharrah", wingSpan: 36.0)
let gryphon = Gryphon(name: "Buckbeak", wingSpan: 21.5)
let kraken = Kraken(name: "Tenticool", swimSpeed: 68)
let merfolk = Merfolk(name: "Triton", swimSpeed: 20)

let monsters: [Monster] = [dragon, gryphon, kraken, merfolk]
printMonsterDetails(monsters: monsters)
